package com.example.project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Login extends AppCompatActivity {
    static final String sharedPref="SharedPref";
    static final String sp_name="Username";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        EditText edtxt_username_lg=(EditText) findViewById(R.id.et1_lg);
        EditText edtxt_password_lg=(EditText) findViewById(R.id.et2_lg);
        Button edtxt_bt1_lg=(Button) findViewById(R.id.et_lg_bt1);
        Button edtxt_bt2_lg=(Button) findViewById(R.id.et_lg_bt2);
        MyDatabase db=new MyDatabase(getApplicationContext());
        edtxt_bt1_lg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Cursor res=db.login(edtxt_username_lg.getText().toString(),edtxt_password_lg.getText().toString());
                if(res.getCount()==0){
                    Toast.makeText(Login.this, "Sorry! Login Failed", Toast.LENGTH_SHORT).show();
                }
                else{
                    SharedPreferences sharedPreferences=getSharedPreferences(sharedPref,MODE_PRIVATE);
                    SharedPreferences.Editor eed=sharedPreferences.edit();
                    eed.putString(sp_name,edtxt_username_lg.getText().toString());
                    eed.apply();
                    while(res.moveToNext()){
                        String role_name=res.getString(3);
                        if(role_name.equals("Admin")){
                            Toast.makeText(Login.this, "Congratulations! You are now Logged in", Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(Login.this,MainActivity.class));
                        }
                        else{
                            Toast.makeText(Login.this, "Congratulations! You are now Logged in", Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(Login.this,Dashboard.class));
                        }
                    }

                }
            }
        });

        edtxt_bt2_lg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),Signup.class));
            }
        });
    }
}