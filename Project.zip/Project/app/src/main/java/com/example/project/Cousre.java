package com.example.project;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class Cousre extends AppCompatActivity {
    Uri ImageUri;
    byte[] imgData;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cousre);
        ListView lv = (ListView) findViewById(R.id.course_lv);
        Button ca_bt1=(Button) findViewById(R.id.ca_bt1);
        Button ca_bt2=(Button) findViewById(R.id.ca_bt2);
        MyDatabase db=new MyDatabase(getApplicationContext());
        ca_bt1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Cousre.this,AddCourse.class));
            }
        });

        ca_bt2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ArrayList<Course_getter>  sc_list=new ArrayList<Course_getter>();
                //to refresh list view
                lv.setAdapter(null);
                sc_list.clear();
                Cursor data = db.Show_courses();
                if (data.getCount() == 0) {
                    Toast.makeText(Cousre.this, "Data Not Found", Toast.LENGTH_SHORT).show();
                } else {
                    while(data.moveToNext()){
                        String cs_id=data.getString(0);
                        String cs_name=data.getString(1);
                        byte[] cs_image=data.getBlob(2);
                        sc_list.add(new Course_getter(cs_id,cs_name,cs_image));
                    }
                    customAdapter cs=new customAdapter(getApplicationContext(),sc_list);
                    lv.setAdapter(cs);

                }
            }
        });
    }

    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==200)
        {
            if(resultCode==RESULT_OK)
            {
                ImageUri=data.getData();
            }
        }
    }
}