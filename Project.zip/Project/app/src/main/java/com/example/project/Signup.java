package com.example.project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Signup extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        EditText edtxt_username_sp=(EditText) findViewById(R.id.et1_sp);
        EditText edtxt_password_sp=(EditText) findViewById(R.id.et2_sp);
        Button edtxt_bt1_sp=(Button) findViewById(R.id.et_sp_bt1);

        edtxt_username_sp.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                validations validation = new validations();
                String name=edtxt_username_sp.getText().toString();
                if(!hasFocus){
                    if (name.isEmpty()){
                        edtxt_username_sp.setError("Enter Your Name");
                    }
                    else if (!validation.fullname(name)){
                        edtxt_username_sp.setError("atleast 3 digist must be there");
                    }
                    else  {
                        edtxt_username_sp.setCompoundDrawablesWithIntrinsicBounds(0, 0,R.drawable.ic_baseline_library_books_24, 0);
                    }
                }
            }
        });

        edtxt_bt1_sp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MyDatabase obj=new MyDatabase(getApplicationContext());
                if(edtxt_username_sp.getText().equals("") || edtxt_password_sp.getText().equals("")){
                    Toast.makeText(Signup.this, "Please Fill all fields", Toast.LENGTH_SHORT).show();
                }
                else{
                    boolean ans= obj.InsertUsers(edtxt_username_sp.getText().toString(),edtxt_password_sp.getText().toString(),"Users");
                    if(ans){
                        Toast.makeText(Signup.this, "Your Account Has Been Created", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(Signup.this,Login.class));
                    }
                    else{
                        Toast.makeText(Signup.this, "Insertion Failed", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }
}